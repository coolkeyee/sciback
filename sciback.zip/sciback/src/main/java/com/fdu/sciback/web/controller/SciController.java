package com.fdu.sciback.web.controller;

import com.fdu.sciback.entity.scis.FieldsEntity;
import com.fdu.sciback.entity.scis.SciEntity;
import com.fdu.sciback.service.ISciService;
import net.sf.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@ResponseBody
@RequestMapping("/sci")
@CrossOrigin
public class SciController {

    @Autowired
    private ISciService sciService;

    @GetMapping("/fields")
    public JSONObject getFields(){
        return sciService.getFields();
    }
}
